import React from 'react'
import img from './mango.jfif'
function Home() {
    return (
        <div>
            <img src={img}></img>
            <h1>LJ University</h1>
        </div>
    )
}

export default Home
