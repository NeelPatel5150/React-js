import React from 'react'

function About() {
    return (
        <div>
            <ul>
                <li>CSE</li>
                <li>CE</li>
                <li>IT</li>
            </ul>
        </div>
    )
}

export default About
