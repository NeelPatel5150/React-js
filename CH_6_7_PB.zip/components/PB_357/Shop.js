import React from 'react'

function Shop() {
  return (
    <div>Shop</div>
  )
}

export default Shop
