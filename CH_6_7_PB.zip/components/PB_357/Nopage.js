import React from 'react'

function Nopage() {
  return (
    <div>Nopage</div>
  )
}

export default Nopage
