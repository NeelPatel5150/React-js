import React from 'react'

import Myapp from './Myapp'
function App(){

   return (
      <div>
        <Myapp/>
      </div>
   )
}
export default App
