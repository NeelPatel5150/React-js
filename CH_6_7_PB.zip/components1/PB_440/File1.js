import React from 'react'
import File2 from './File2'

function File1() {
    return (
        <>
            <File2/>    
        </>
    )
}

export default File1
